<?

//
function authenticate()
{
	Header("WWW-Authenticate: Basic realm=\"RESTRICTED ACCESS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo ("<h1>INVALID USERNAME OR PASSWORD. ACCESS DENIED<h1>");
    exit;

}

function check_pass($login, $passwd, $mode)
{
	global $password_file;
	if(!$fh = fopen($password_file, "r")) { die("<P>Could Not Open Password File"); }

	$match = 0;
    while(!feof($fh)) 
    {
    	$line = fgets($fh, 4096);
        $from_file = explode(":", $line);
        if($from_file[0] == $login) 
 		{
 			if($mode == "crypt")
 			{
 				$salt = substr($from_file[1],0,2);
            	$user_pass = crypt($password,$salt);
        	} 
        	elseif ($mode == "md5") 
        	{
          		$user_pass = md5($password);
        	}
        	if(rtrim($from_file[1]) == $user_pass) 
        	{
          		$match = 1;
          		break;
       		}
     	}
   }
   
   if($match) 
   {
     return 1;
   }
   else 
   {
     return 0;
   }
   fclose($fh);
}


$mode = "md5";
$password_file = "../secrets/members.txt";
//
function request_password()
{
	if (!isset($PHP_AUTH_USER)) 
	{
    	authenticate();
	}
	else 
	{
    if(check_pass($PHP_AUTH_USER, $PHP_AUTH_PW, $mode)) 
    {
      ?>
      <h1>ACCEPTED</h1>
      <?
    } 
    else 
    {
    	authenticate();
    }
  }
}
?>