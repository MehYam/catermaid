<?
include("functions/install.php");

// creeaza si initializeaza fisierul public.xml
init_public_file();

// creeaza si initializeaza fisierul nepublic.xml
init_nepublic_file();

?>