<?
// formular de introducere a feedback-ului 
function add_feedback_form()
{
	?>
		<FORM action="index.php" method="post" id="feedback_form">
			<TEXTAREA cols="77" rows="10" name="message"></TEXTAREA></BR>
			<INPUT type="submit" name="add" value="Add">
		</FORM>
	<?PHP
}




// introducere date in fisierul public.xml
function put_public_data($post_data)
{
	chdir("../public");
	$filename = "public.xml";
	
	$message = $post_data["message"];
	
	$date = getdate();
	$date=$date['month'].".".$date['mday'].".".$date['year'];
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	
	/* la fiecare apel am de scris 3 linii
		- linia 1 - <date>date</date>
		- linia 2 - <ip>ip</ip>
		- linia 3 - <message>message</message>
		
	OBSERVATIE : aceste linii vor trebui scrise inainte de tagul de final </public>
	*/
	
	
	$top = "<feedback>";
	$line = "<date>".$date."</date>";
	$line.= "<ip>".$ip."</ip>";
	$line.= "<message>".$message."</message>";
	$bottom = "</feedback>";
	
	
	/* OBSERVATIE: citesc fisierul mai putin ultimul tag si il recreez cu informatia acualizata */
	
	// deschid fisierul
	$fh = fopen($filename,"r");
	
	$filesize =  filesize($filename);
	$length = $filesize - 9; // 9 = length("</public>")
	
	$data = fread($fh, $length);
	fclose($fh);
	
	// redeschis fisierul dar ii reduc lungimea la 0
	$fh = fopen($filename, "w");
	
	// scriu datele deja existente
	fwrite($fh, $data, $length);
	
	// scriu datele
	fwrite($fh, $top);
	fwrite($fh, $line);
	fwrite($fh, $bottom);
	
	// scriu elementul de sfarsit - </public>
	fwrite($fh, "</public>");
	
	fclose($fh);
}
?>