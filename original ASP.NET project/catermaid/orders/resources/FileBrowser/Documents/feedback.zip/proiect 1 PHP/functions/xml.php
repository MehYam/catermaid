<STYLE type="text/css">

</STYLE>

<?php

$TagsOpen = array(
	"public" => 0,
	"nepublic" => 0,
	"feedback" => 0,
	"date" => 0,
	"ip" => 0,
	"message" => 0,
);

/*  variabila ce ajuta la desenarea in diferite culori ale backgroundului ...
	0 inseamna o culoare 1 alta culoar 
*/
$contor = 0;

// trateaza elemtele de start din fisierul XML (Ex:<data>)
function startElement($xml_parser, $name, $attributes)
{
	global $TagsOpen;
	global $contor;
	
	switch ($name)
	{
		case "PUBLIC":
			$TagsOpen["public"] = 1;
			?>
				<TABLE cellpadding="2" cellspacing="2" width="100%" bgcolor="gray">
				<tr><td width="100%" bgcolor="White">
				<span id="title" class="title">Public Data</span>
				</td>
				</tr>
				</TABLE>
				
				<TABLE cellpadding="1" cellspacing="1" width="100%" bgcolor="gray">
				
			<?
		break;
		
		case "NEPUBLIC":
			$TagsOpen["nepublic"] = 1;
			?>
				<TABLE cellpadding="2" cellspacing="2" width="100%" bgcolor="gray" border="0">
				<tr><td width="100%" bgcolor="White">
				<span id="title" class="title">Non-Public Data </span></BR><span class="madeby">(require authentication)</span>
				</td>
				</tr>
				</TABLE>
				
				<TABLE cellpadding="1" cellspacing="1" width="100%" bgcolor="gray" border="0">
			
			<?
		break;
		
		case "FEEDBACK":
			$TagsOpen["feedback"] = 1;
			
			if ($contor==0)
			{
				$bgcolor = "khaki";
				$contor = 1;
			}
			else 
			{
				$bgcolor = "lightyellow";
				$contor = 0;
			}
				
			?>
				
				<tr bgcolor="Gray"><td width="100%">
				<table cellpadding="0" cellspacing="1"  bgcolor="<?echo $bgcolor;?>" width="100%" >
				<TR><TD width="90%">
			<?
			
		break;
			
		case "DATE":
			$TagsOpen["date"] = 1;
			?>
				<span class="date">&nbsp;Date:</span>
			<?
		break;
			
		case "IP":
			$TagsOpen["ip"] = 1;
			?>
				<span class="ip">IP:</span>
			<?
		break;
			
		case "MESSAGE":
			$TagsOpen["message"] = 1;
			?>
				</BR>
				<span class="message">Message:</span>
			<?
		break;		
	}
};

// trateaza elementele de final (Ex:</data>)
function endElement($xml_parser, $name)
{
	global $TagsOpen;
	
	switch ($name)
	{
		case "PUBLIC":
			$TagsOpen["public"] = 0;
			?>
				</TABLE>
				<H3 class="navy">Your Message:</H3>
			<?
		break;
			
		case "NEPUBLIC":
			$TagsOpen["nepublic"] = 0;
			?>
				</TABLE>
				<H3 class="navy">Your Message:</H3>
			<?
		break;
		
		case "FEEDBACK":
			$TagsOpen["feedback"] = 0;
			
			/* la terminarea procesarii unui feedback inserez un link catre introducerea de feedback*/
			?>
				</TD>
				
				<td align="right" bgcolor="<?echo $bgcolor;?>" valign="bottom">
					<A href="index.php#feedback_form" class="link">Reply</A>&nbsp;|&nbsp;
				</TD>
				<td align="right" bgcolor="<?echo $bgcolor;?>" valign="bottom">
					<A href="index.php#title" class="link">Up</A>
				</TD>
				
				</TR>
				</TABLE>
			<?
		break;
			
		case "DATE":
			$TagsOpen["date"] = 0;
		break;
			
		case "IP":
			$TagsOpen["ip"] = 0;
		break;
			
		case "MESSAGE":
			$TagsOpen["message"] = 0;
			echo "</br></br>";
		break;		
	};
};

// trateaza datele (Ex:<data>DATA DE AZI</data>)
function characterData($xml_parser, $data)
{
	global $TagsOpen;
	
	if ($data!="\n")
	{			
		if ($TagsOpen["date"] == 1)
		{
			?>
				<SPAN class="characters"><?echo $data;?></SPAN>
			<?
		}
			
		if ($TagsOpen["ip"] == 1)
		{
			?>
				<SPAN class="characters"><?echo $data;?></SPAN>
			<?
		}
		
		if ($TagsOpen["message"] == 1)
		{
			?>
				<SPAN class="messagetext"><?echo $data;?></SPAN>
			<?
		}
	};
};

// returneaza continutul fisierului($file)
function load_data($file)
{
	$fh = fopen($file, "r") or die("Error file.");
	$data = fread($fh, filesize($file));
	return $data;
};



// afiseaza continutul fisierului public.xml/nepublic.xml 
// functia genereaza inclusiv formatatea textului
function show_data($filename)
{
	// un fel de main
	if ($filename == "public.xml")
		chdir("../public");
	else 	
		chdir("../nepublic");
	
	$xml_parser = xml_parser_create();
	
	xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, true);
	
	xml_set_element_handler($xml_parser, "startElement", "endElement");
	
	xml_set_character_data_handler($xml_parser, "characterData");
	
	xml_parse($xml_parser, load_data($filename)) or die("Error parsing XML file");
	
	xml_parser_free($xml_parser);
}







?>