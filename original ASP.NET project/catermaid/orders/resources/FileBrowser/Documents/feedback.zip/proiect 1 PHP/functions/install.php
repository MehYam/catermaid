<?
// creeaza si initializeaza fisierul public.xml
function init_public_file()
{
	$fh = fopen("xml/public.xml","w");
	
	$header = "<?xml version='1.0' encoding='UTF-8'?>";
	
	$root = "<public></public>";
	
	fwrite($fh, $header);
	
	fwrite($fh, $root);
}

// creeaza si initializeaza fisierul nepublic.xml
function init_nepublic_file()
{
	$fh = fopen("xml/nepublic.xml","w");
	
	$header = "<?xml version='1.0' encoding='UTF-8'?>";
	
	$root = "<nepublic></nepublic>";
	
	fwrite($fh, $header);
	
	fwrite($fh, $root);
}
?>