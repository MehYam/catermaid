
<?PHP

//error_reporting(E_ALL);

// testez daca s-a dat click pe Add si daca mesajul are continut
if ($HTTP_POST_VARS["add"] == "Add")
{
	// aici trebuie facut un refresh la pagina pt. a se putea viziualiza mesajul nou introdus	
	header("Location:index.php");
}

include("../functions/xml.php");
include("functions.php");

// pt. a putea introduce datele publice
include("../public/functions.php");

// introducerea mesajului nou
if ($HTTP_POST_VARS["add"] == "Add") 
	if ($HTTP_POST_VARS["public"])
		
		// mesaj public	
		put_public_data($HTTP_POST_VARS);

	else
		
		// mesaj nepublic
		put_nepublic_data($HTTP_POST_VARS); 
		

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<LINK href="../style.css" type="text/css" rel="stylesheet"></LINK>

</head>
<body>

<TABLE width="65%" align="center">
<TR><td>
<?php


// afisez continutul fisierului public.xml
$filename = "nepublic.xml";
show_data($filename);


?>
</TD></TR></TABLE>

<TABLE cellpadding="0" cellspacing="0" width="65%" align="center">
<TR><td height="17%"></TD></TR>
<TR bgcolor="white"><TD>
<?

// formularul de introducere de noi mesaje
echo "<div align='left'>";
add_feedback_form_complete();
echo "</div>";

?>

</TD></TR>
<TR bgcolor="white"><TD align="right"><SPAN class="madeby">Made by</SPAN> <A href="mailto:cb@infoiasi.ro" class="cb">cb@infoiasi.ro</A></TD></TR>
</TABLE>

</body>
</html>
